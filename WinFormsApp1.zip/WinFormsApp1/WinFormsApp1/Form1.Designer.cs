﻿namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            trackBarConveyor1 = new TrackBar();
            btnStart = new Button();
            lblConveyor1_1 = new Label();
            lblConveyor1_2 = new Label();
            lblConveyor1_3 = new Label();
            lblConveyor1_4 = new Label();
            lblConveyor2_4 = new Label();
            lblConveyor2_3 = new Label();
            lblConveyor2_2 = new Label();
            lblConveyor2_1 = new Label();
            btnStop = new Button();
            trackBarConveyor2 = new TrackBar();
            lblConveyor1Speed = new Label();
            lblConveyor2Speed = new Label();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            textBox3 = new TextBox();
            radioButton1 = new RadioButton();
            radioButton2 = new RadioButton();
            radioButton3 = new RadioButton();
            radioButton4 = new RadioButton();
            textBox4 = new TextBox();
            textBox5 = new TextBox();
            textBox6 = new TextBox();
            textBox7 = new TextBox();
            label5 = new Label();
            ((System.ComponentModel.ISupportInitialize)trackBarConveyor1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)trackBarConveyor2).BeginInit();
            SuspendLayout();
            // 
            // trackBarConveyor1
            // 
            trackBarConveyor1.Location = new Point(25, 195);
            trackBarConveyor1.Name = "trackBarConveyor1";
            trackBarConveyor1.Size = new Size(357, 45);
            trackBarConveyor1.TabIndex = 2;
            trackBarConveyor1.Scroll += trackBarConveyor1_Scroll;
            // 
            // btnStart
            // 
            btnStart.Location = new Point(439, 193);
            btnStart.Name = "btnStart";
            btnStart.Size = new Size(132, 45);
            btnStart.TabIndex = 3;
            btnStart.Text = "Запустить";
            btnStart.UseVisualStyleBackColor = true;
            btnStart.Click += btnStart_Click;
            // 
            // lblConveyor1_1
            // 
            lblConveyor1_1.AutoSize = true;
            lblConveyor1_1.BackColor = SystemColors.ControlDarkDark;
            lblConveyor1_1.Location = new Point(111, 49);
            lblConveyor1_1.Name = "lblConveyor1_1";
            lblConveyor1_1.Size = new Size(61, 13);
            lblConveyor1_1.TabIndex = 4;
            lblConveyor1_1.Text = "_________";
            lblConveyor1_1.Click += lblConveyor1_1_Click;
            // 
            // lblConveyor1_2
            // 
            lblConveyor1_2.AutoSize = true;
            lblConveyor1_2.BackColor = SystemColors.ControlDarkDark;
            lblConveyor1_2.Location = new Point(195, 49);
            lblConveyor1_2.Name = "lblConveyor1_2";
            lblConveyor1_2.Size = new Size(61, 13);
            lblConveyor1_2.TabIndex = 5;
            lblConveyor1_2.Text = "_________";
            lblConveyor1_2.Click += lblConveyor1_2_Click;
            // 
            // lblConveyor1_3
            // 
            lblConveyor1_3.AutoSize = true;
            lblConveyor1_3.BackColor = SystemColors.ControlDarkDark;
            lblConveyor1_3.Location = new Point(283, 49);
            lblConveyor1_3.Name = "lblConveyor1_3";
            lblConveyor1_3.Size = new Size(61, 13);
            lblConveyor1_3.TabIndex = 6;
            lblConveyor1_3.Text = "_________";
            lblConveyor1_3.Click += lblConveyor1_3_Click;
            // 
            // lblConveyor1_4
            // 
            lblConveyor1_4.AutoSize = true;
            lblConveyor1_4.BackColor = SystemColors.ControlDarkDark;
            lblConveyor1_4.Location = new Point(365, 49);
            lblConveyor1_4.Name = "lblConveyor1_4";
            lblConveyor1_4.RightToLeft = RightToLeft.No;
            lblConveyor1_4.Size = new Size(61, 13);
            lblConveyor1_4.TabIndex = 7;
            lblConveyor1_4.Text = "_________";
            lblConveyor1_4.Click += lblConveyor1_4_Click;
            // 
            // lblConveyor2_4
            // 
            lblConveyor2_4.AutoSize = true;
            lblConveyor2_4.BackColor = SystemColors.ControlDarkDark;
            lblConveyor2_4.Location = new Point(367, 114);
            lblConveyor2_4.Name = "lblConveyor2_4";
            lblConveyor2_4.Size = new Size(61, 13);
            lblConveyor2_4.TabIndex = 11;
            lblConveyor2_4.Text = "_________";
            lblConveyor2_4.Click += lblConveyor2_4_Click;
            // 
            // lblConveyor2_3
            // 
            lblConveyor2_3.AutoSize = true;
            lblConveyor2_3.BackColor = SystemColors.ControlDarkDark;
            lblConveyor2_3.Location = new Point(283, 114);
            lblConveyor2_3.Name = "lblConveyor2_3";
            lblConveyor2_3.Size = new Size(61, 13);
            lblConveyor2_3.TabIndex = 10;
            lblConveyor2_3.Text = "_________";
            lblConveyor2_3.Click += lblConveyor2_3_Click;
            // 
            // lblConveyor2_2
            // 
            lblConveyor2_2.AutoSize = true;
            lblConveyor2_2.BackColor = SystemColors.ControlDarkDark;
            lblConveyor2_2.Location = new Point(195, 114);
            lblConveyor2_2.Name = "lblConveyor2_2";
            lblConveyor2_2.Size = new Size(61, 13);
            lblConveyor2_2.TabIndex = 9;
            lblConveyor2_2.Text = "_________";
            lblConveyor2_2.Click += lblConveyor2_2_Click;
            // 
            // lblConveyor2_1
            // 
            lblConveyor2_1.AutoSize = true;
            lblConveyor2_1.BackColor = SystemColors.ControlDarkDark;
            lblConveyor2_1.Location = new Point(109, 114);
            lblConveyor2_1.Name = "lblConveyor2_1";
            lblConveyor2_1.Size = new Size(61, 13);
            lblConveyor2_1.TabIndex = 8;
            lblConveyor2_1.Text = "_________";
            lblConveyor2_1.Click += lblConveyor2_1_Click;
            // 
            // btnStop
            // 
            btnStop.Location = new Point(439, 254);
            btnStop.Name = "btnStop";
            btnStop.Size = new Size(132, 45);
            btnStop.TabIndex = 12;
            btnStop.Text = "Остановить";
            btnStop.UseVisualStyleBackColor = true;
            btnStop.Click += btnStop_Click;
            // 
            // trackBarConveyor2
            // 
            trackBarConveyor2.Location = new Point(25, 270);
            trackBarConveyor2.Name = "trackBarConveyor2";
            trackBarConveyor2.Size = new Size(357, 45);
            trackBarConveyor2.TabIndex = 13;
            trackBarConveyor2.Scroll += trackBarConveyor2_Scroll;
            // 
            // lblConveyor1Speed
            // 
            lblConveyor1Speed.AutoSize = true;
            lblConveyor1Speed.Location = new Point(25, 179);
            lblConveyor1Speed.Name = "lblConveyor1Speed";
            lblConveyor1Speed.Size = new Size(124, 13);
            lblConveyor1Speed.TabIndex = 14;
            lblConveyor1Speed.Text = "Скорость конвейера 1:";
            lblConveyor1Speed.Click += lblConveyor1Speed_Click;
            // 
            // lblConveyor2Speed
            // 
            lblConveyor2Speed.AutoSize = true;
            lblConveyor2Speed.Location = new Point(25, 254);
            lblConveyor2Speed.Name = "lblConveyor2Speed";
            lblConveyor2Speed.Size = new Size(124, 13);
            lblConveyor2Speed.TabIndex = 15;
            lblConveyor2Speed.Text = "Скорость конвейера 2:";
            lblConveyor2Speed.Click += lblConveyor2Speed_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.DarkGray;
            label1.ForeColor = Color.Red;
            label1.Location = new Point(25, 49);
            label1.Name = "label1";
            label1.Size = new Size(65, 13);
            label1.TabIndex = 16;
            label1.Text = "Конвейер 1";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.DarkGray;
            label2.ForeColor = Color.Red;
            label2.Location = new Point(25, 114);
            label2.Name = "label2";
            label2.Size = new Size(65, 13);
            label2.TabIndex = 17;
            label2.Text = "Конвейер 2";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = SystemColors.ButtonShadow;
            label3.Location = new Point(111, 62);
            label3.Name = "label3";
            label3.Size = new Size(319, 13);
            label3.TabIndex = 18;
            label3.Text = "____________________________________________________";
            label3.Click += label3_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = SystemColors.ButtonShadow;
            label4.Location = new Point(109, 127);
            label4.Name = "label4";
            label4.Size = new Size(325, 13);
            label4.TabIndex = 19;
            label4.Text = "_____________________________________________________";
            // 
            // textBox1
            // 
            textBox1.BackColor = Color.Silver;
            textBox1.Location = new Point(9, 163);
            textBox1.Multiline = true;
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(571, 164);
            textBox1.TabIndex = 20;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(440, 96);
            textBox2.Multiline = true;
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(86, 44);
            textBox2.TabIndex = 21;
            // 
            // textBox3
            // 
            textBox3.BorderStyle = BorderStyle.FixedSingle;
            textBox3.Location = new Point(531, 114);
            textBox3.Multiline = true;
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(26, 26);
            textBox3.TabIndex = 22;
            // 
            // radioButton1
            // 
            radioButton1.AutoSize = true;
            radioButton1.Location = new Point(451, 144);
            radioButton1.Name = "radioButton1";
            radioButton1.Size = new Size(14, 13);
            radioButton1.TabIndex = 23;
            radioButton1.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            radioButton2.AutoSize = true;
            radioButton2.Location = new Point(531, 144);
            radioButton2.Name = "radioButton2";
            radioButton2.Size = new Size(14, 13);
            radioButton2.TabIndex = 24;
            radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton3
            // 
            radioButton3.AutoSize = true;
            radioButton3.Location = new Point(531, 79);
            radioButton3.Name = "radioButton3";
            radioButton3.Size = new Size(14, 13);
            radioButton3.TabIndex = 28;
            radioButton3.UseVisualStyleBackColor = true;
            // 
            // radioButton4
            // 
            radioButton4.AutoSize = true;
            radioButton4.Location = new Point(451, 79);
            radioButton4.Name = "radioButton4";
            radioButton4.Size = new Size(14, 13);
            radioButton4.TabIndex = 27;
            radioButton4.UseVisualStyleBackColor = true;
            // 
            // textBox4
            // 
            textBox4.BorderStyle = BorderStyle.FixedSingle;
            textBox4.Location = new Point(531, 49);
            textBox4.Multiline = true;
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(26, 26);
            textBox4.TabIndex = 26;
            // 
            // textBox5
            // 
            textBox5.Location = new Point(440, 31);
            textBox5.Multiline = true;
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(86, 44);
            textBox5.TabIndex = 25;
            // 
            // textBox6
            // 
            textBox6.BackColor = Color.DarkGray;
            textBox6.Location = new Point(12, 31);
            textBox6.Multiline = true;
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(86, 44);
            textBox6.TabIndex = 29;
            // 
            // textBox7
            // 
            textBox7.BackColor = Color.DarkGray;
            textBox7.Location = new Point(12, 96);
            textBox7.Multiline = true;
            textBox7.Name = "textBox7";
            textBox7.Size = new Size(86, 44);
            textBox7.TabIndex = 30;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(556, 177);
            label5.Name = "label5";
            label5.Size = new Size(15, 13);
            label5.TabIndex = 31;
            label5.Text = "O";
            label5.Click += label5_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(6F, 13F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(592, 333);
            Controls.Add(label5);
            Controls.Add(radioButton3);
            Controls.Add(radioButton4);
            Controls.Add(textBox4);
            Controls.Add(textBox5);
            Controls.Add(radioButton2);
            Controls.Add(radioButton1);
            Controls.Add(textBox3);
            Controls.Add(textBox2);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(lblConveyor2Speed);
            Controls.Add(lblConveyor1Speed);
            Controls.Add(trackBarConveyor2);
            Controls.Add(btnStop);
            Controls.Add(lblConveyor2_4);
            Controls.Add(lblConveyor2_3);
            Controls.Add(lblConveyor2_2);
            Controls.Add(lblConveyor2_1);
            Controls.Add(lblConveyor1_4);
            Controls.Add(lblConveyor1_3);
            Controls.Add(lblConveyor1_2);
            Controls.Add(lblConveyor1_1);
            Controls.Add(btnStart);
            Controls.Add(trackBarConveyor1);
            Controls.Add(textBox1);
            Controls.Add(textBox6);
            Controls.Add(textBox7);
            Name = "Form1";
            Text = "2";
            ((System.ComponentModel.ISupportInitialize)trackBarConveyor1).EndInit();
            ((System.ComponentModel.ISupportInitialize)trackBarConveyor2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private TrackBar trackBarConveyor1;
        private Button btnStart;
        private Label lblConveyor1_1;
        private Label lblConveyor1_2;
        private Label lblConveyor1_3;
        private Label lblConveyor1_4;
        private Label lblConveyor2_4;
        private Label lblConveyor2_3;
        private Label lblConveyor2_2;
        private Label lblConveyor2_1;
        private Button btnStop;
        private TrackBar trackBarConveyor2;
        private Label lblConveyor1Speed;
        private Label lblConveyor2Speed;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private TextBox textBox1;
        private TextBox textBox2;
        private TextBox textBox3;
        private RadioButton radioButton1;
        private RadioButton radioButton2;
        private RadioButton radioButton3;
        private RadioButton radioButton4;
        private TextBox textBox4;
        private TextBox textBox5;
        private TextBox textBox6;
        private TextBox textBox7;
        private Label label5;
    }
}
